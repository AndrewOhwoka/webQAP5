// Function to read the JSON file and iterate through the array

// Read the file from disk
fetch('./people.json')
// The file is convert to JSON
    .then(response => response.json())
    // Put date into name variable (people)   
    .then(people => {
        // Iterate through the array using forEach
        people.forEach(record => {
          // Display one message while accessing each array object
          console.log(`ID: ${record.id}, Name: ${record.name}, Age: ${record.age}`);
        });
      })
      .catch(error => {
        console.error(error);
    });
  

  
  
